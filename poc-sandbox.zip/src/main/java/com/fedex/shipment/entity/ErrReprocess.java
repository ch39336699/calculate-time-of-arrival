package com.fedex.shipment.entity;

public class ErrReprocess {

  String myString;

  public String getNewMyString() {
    return myString;
  }

  public void setNewMyString(String myString) {
    this.myString = myString;
  }
}
